#!/bin/bash

LEASE_FILE="/var/lib/dhcp/dhcpd.leases"
OUTPUT_FILE="/var/lib/node_exporter/textfile_collector/dhcp.prom"

LEASE_COUNT=$(grep -c "lease " $LEASE_FILE)

cat <<EOF > $OUTPUT_FILE
# HELP dhcp_active_leases Number of active DHCP leases
# TYPE dhcp_active_leases gauge
dhcp_active_leases $LEASE_COUNT
EOF