<?php include("backEnd/appHeader.php"); ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalación de aplicaciones</title>
    <!-- Se usa Bootstrap 5 desde CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        /* Estética global similar a la del formulario de backup */
        body { 
            background-color: #f8f9fa; 
        }
        .container { 
            max-width: 600px; 
            margin-top: 50px; 
        }
        .form-container { 
            background: white; 
            padding: 20px; 
            border-radius: 10px; 
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
        }
        .btn-primary { 
            width: 100%; 
        }
        /* Estilos para selección de logos */
        .hidden { 
            display: none; 
        }
        .logo-option { 
            cursor: pointer; 
            border: 2px solid transparent; 
            padding: 10px; 
            width: 100px; 
            transition: border-color 0.3s ease;
        }
        .logo-option.selected { 
            border-color: #007bff; 
        }
        .logo-container { 
            text-align: center; 
        }
        .logo-label { 
            display: block; 
            margin-top: 5px; 
            font-weight: bold; 
        }
        /* Modal y demás estilos se mantienen */
        .modal-backdrop {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background-color: rgba(0, 0, 0, 0.1) !important;
            backdrop-filter: blur(4px);
            z-index: 1050;
        }
        .modal-dialog {
            display: flex;
            align-items: center;
            min-height: 100vh;
        }
    </style>
</head>
<body>
    <!-- Navbar responsiva -->
    <?php include("view/nav.php"); ?>

    <div class="container mt-5">
        <div class="form-container">
            <h2 class="text-center">Configuración del servidor</h2>
            <form id="installForm" action="do.php" method="POST" class="needs-validation" novalidate>
                <div class="row text-center my-4 justify-content-center">
                    <div class="col-6 col-md-3 logo-container">
                        <img src="img/lamp.png" class="img-fluid logo-option" data-option="lamp">
                        <span class="logo-label">LAMP</span>
                    </div>
                    <div class="col-6 col-md-3 logo-container">
                        <img src="img/wp.png" class="img-fluid logo-option" data-option="wordpress">
                        <span class="logo-label">WORDPRESS</span>
                    </div>
                    <div class="col-6 col-md-3 logo-container">
                        <img src="img/nc.png" class="img-fluid logo-option" data-option="nextcloud">
                        <span class="logo-label">NEXTCLOUD</span>
                    </div>
                    <div class="col-6 col-md-3 logo-container">
                        <img src="img/moodle.png" class="img-fluid logo-option" data-option="moodle">
                        <span class="logo-label">MOODLE</span>
                    </div>
                    <div class="col-6 col-md-3 logo-container">
                        <img src="img/dhcpserver.png" class="img-fluid logo-option" data-option="dhcp">
                        <span class="logo-label">ISC-DHCP-SERVER</span>
                    </div>
                    <div class="col-6 col-md-3 logo-container">
                        <img src="img/bind9.jpg" class="img-fluid logo-option" data-option="dns">
                        <span class="logo-label">BIND9</span>
                    </div>
                    <div class="col-6 col-md-3 logo-container">
                        <img src="img/vpn.png" class="img-fluid logo-option" data-option="vpn">
                        <span class="logo-label">VPN</span>
                    </div>
                    <div class="col-6 col-md-3 logo-container">
                        <img src="img/pg.png" class="img-fluid logo-option" data-option="progra">
                        <span class="logo-label">PROMETHEUS + GRAFANA</span>
                    </div>
                    <div class="col-6 col-md-3 logo-container">
                        <img src="img/grafana.svg" class="img-fluid logo-option" data-option="grafana">
                        <span class="logo-label">GRAFANA DASHBOARDS</span>
                    </div>
                </div>

                <!-- Campos comunes con iconos en cada input -->
                <div id="common-fields" class="hidden">
                    <h4>Datos FTP y MySQL</h4>
                    <div class="mb-3">
                        <label for="ftp_user" class="form-label">Usuario FTP</label>
                        <div class="input-group">
                            <span class="input-group-text">👤</span>
                            <input type="text" id="ftp_user" name="ftp_user" class="form-control" placeholder="Usuario FTP" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="ftp_pass" class="form-label">Contraseña FTP</label>
                        <div class="input-group">
                            <span class="input-group-text">🔑</span>
                            <input type="password" id="ftp_pass" name="ftp_pass" class="form-control" placeholder="Contraseña FTP" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="mysql_root" class="form-label">Contraseña MySQL root</label>
                        <div class="input-group">
                            <span class="input-group-text">🗄</span>
                            <input type="password" id="mysql_root" name="mysql_root" class="form-control" placeholder="Contraseña MySQL root" required>
                        </div>
                    </div>
                </div>

                <!-- Campos dinámicos por opción, con iconos -->
                <div id="dynamic-fields"></div>
                
                <div class="text-center mt-5">
                    <button type="submit" class="btn btn-primary w-25">Instalar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal de Confirmación -->
    <div class="modal fade" id="confirmationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirmar instalación</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Por favor, verifica los datos antes de continuar:</strong></p>
                    <ul id="confirmationList"></ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" id="confirmInstall" class="btn btn-primary">Confirmar</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            setTimeout(() => $('body').addClass('show'), 100);

            $('.logo-option').click(function() {
                $(this).toggleClass('selected');
                let selectedOptions = $('.logo-option.selected');
                $('#common-fields').toggle(selectedOptions.length > 0);
                updateDynamicFields();
            });

            function updateDynamicFields() {
                $('#dynamic-fields').html('');
                $('.logo-option.selected').each(function() {
                    let option = $(this).data('option');
                    let html = `<div class='mt-3'><h4>${option.toUpperCase()}</h4>`;

                    // Campos personalizados por opción
                    if(option === 'wordpress') {
                        html += `
                            <div class='mb-3'>
                                <label class='form-label'>Usuario WordPress</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>👤</span>
                                    <input type='text' name='wp_user' class='form-control' placeholder='Usuario WordPress' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Contraseña WordPress</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='password' name='wp_pass' class='form-control' placeholder='Contraseña WordPress' required>
                                </div>
                            </div>
                        `;
                    } else if(option === 'nextcloud') {
                        html += `
                            <div class='mb-3'>
                                <label class='form-label'>Usuario Nextcloud</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>👤</span>
                                    <input type='text' name='nc_user' class='form-control' placeholder='Usuario Nextcloud' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Contraseña Nextcloud</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='password' name='nc_pass' class='form-control' placeholder='Contraseña Nextcloud' required>
                                </div>
                            </div>
                        `;
                    } else if(option === 'moodle') {
                        html += `
                            <div class='mb-3'>
                                <label class='form-label'>Usuario Moodle</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>👤</span>
                                    <input type='text' name='moodle_user' class='form-control' placeholder='Usuario Moodle' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Contraseña Moodle</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='password' name='moodle_pass' class='form-control' placeholder='Contraseña Moodle' required>
                                </div>
                            </div>
                        `;
                    } else if(option === 'lamp') {
                        html += `
                            <div class='mb-3'>
                                <label class='form-label'>Usuario LAMP</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>👤</span>
                                    <input type='text' name='lamp_user' class='form-control' placeholder='Usuario LAMP' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Contraseña LAMP</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='password' name='lamp_pass' class='form-control' placeholder='Contraseña LAMP' required>
                                </div>
                            </div>
                        `;
                    } else if(option === 'dhcp') {
                        html += `
                            <div class='mb-3'>
                                <label class='form-label'>Red DHCP</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='text' name='dhcp_ip_net' class='form-control' placeholder='Dirección IP de la red DHCP' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Máscara de red</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='text' name='dhcp_mask' class='form-control' placeholder='Máscara de red' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Dirección inicial DHCP</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='text' name='dhcp_ip_range1' class='form-control' placeholder='IP inicial' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Dirección final DHCP</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='text' name='dhcp_ip_range2' class='form-control' placeholder='IP final' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Gateway de la Red DHCP</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='text' name='dhcp_gateway' class='form-control' placeholder='IP de puerta de enlace de la red' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>DNS 1 DHCP</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='text' name='dhcp_dns1' class='form-control' placeholder='Primer IP de DNS' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>DNS 2 DHCP</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='text' name='dhcp_dns2' class='form-control' placeholder='Segunda IP de DNS' required>
                                </div>
                            </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Interfaz de red DHCP</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='text' name='dhcp_interface' class='form-control' placeholder='Interfaz de red DHCP' required>
                                </div>
                            </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>IP del Broadcast</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='text' name='dhcp_broadcast_ip' class='form-control' placeholder='IP del Broadcast' required>
                                </div>
                            </div>
                        `;
                    } else if(option === 'dns') {
                        html += `
                            <div class='mb-3'>
                                <label class='form-label'>Forwarder 1 DNS</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>👤</span>
                                    <input type='text' name='dns_forwarder1' class='form-control' placeholder='Primer forwarder' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Forwarder 2 DNS</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='text' name='dns_forwarder2' class='form-control' placeholder='Segundo forwarder' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>IP de escucha DNS</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>👤</span>
                                    <input type='text' name='dns_listen_ip' class='form-control' placeholder='IP por la que escucha' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Dominio</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='text' name='dns_domain' class='form-control' placeholder='Nombre de dominio' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>IP del DNS server</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>👤</span>
                                    <input type='text' name='dns_ip_server' class='form-control' placeholder='IP del DNS server' required>
                                </div>
                            </div>
                        `;
                    } else if(option === 'vpn') {
                        html += `
                            <div class='mb-3'>
                                <label class='form-label'>Interfaz VPN</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='text' name='vpn_interface' class='form-control' placeholder='Interfaz VPN' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Red de la VPN</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>👤</span>
                                    <input type='text' name='openvpn_subnet' class='form-control' placeholder='Red de la VPN' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Nombre de usuario VPN</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='text' name='client_name' class='form-control' placeholder='Nombre del usuario cliente' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>IP del servidor VPN</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>👤</span>
                                    <input type='text' name='vpn_ip_server' class='form-control' placeholder='IP del servidor VPN' required>
                                </div>
                            </div>
                        `;
                    } else if(option === 'progra') {
                        html += `
                            <input type="hidden" name="progra_selected" value="1">
                            <div class='mb-3'>
                                <label class='form-label'>Versión de Prometheus</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔢</span>
                                    <input type='text' name='progra_prometheus_version' class='form-control' placeholder='Ej: 2.52.0' value='2.52.0' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Versión de Grafana</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔢</span>
                                    <input type='text' name='progra_grafana_version' class='form-control' placeholder='Ej: 10.1.4' value='10.1.4' required>
                                </div>
                            </div>
                        `;
                    } else if(option === 'grafana') {
                        html += `
                            <input type="hidden" name="grafana_selected" value="1">
                            <div class='mb-3'>
                                <label class='form-label'>URL del Dashboard</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🌐</span>
                                    <input type='text' name='grafana_url' class='form-control' placeholder='URL del Dashboard' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Token de API</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='text' name='grafana_api' class='form-control' placeholder='Token de API' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <button class="btn btn-info btn-sm" type="button" data-bs-toggle="collapse" data-bs-target="#grafanaHelp" aria-expanded="false" aria-controls="grafanaHelp">
                                    Ayuda
                                </button>
                                <div class="collapse mt-2" id="grafanaHelp">
                                    <div class="card card-body">
                                        <strong>¿Qué es el Token de API?</strong><br>
                                        El token de API de Grafana te permite automatizar la importación de dashboards y otras tareas desde scripts o aplicaciones externas.<br>
                                        <br>
                                        <strong>¿Dónde se obtiene?</strong><br>
                                        Entra en Grafana &gt; Configuration &gt; API Keys y genera uno con permisos adecuados.<br>
                                        <br>
                                        <strong>¿Qué poner en la URL del Dashboard?</strong><br>
                                        Es la URL pública o interna desde la que accederás a tu dashboard de Grafana, por ejemplo: <code>http://tu-servidor:3000/d/abc123/mi-dashboard</code>
                                    </div>
                                </div>
                            </div>
                        `;
                    } else {
                        html += `<p>No hay campos específicos para ${option}.</p>`;
                    }
                    // Puedes añadir más opciones aquí...

                    // Campos comunes SOLO para ciertas opciones
                    if(['lamp','wordpress','nextcloud','moodle'].includes(option)) {
                        html += `
                            <div class='mb-3'>
                                <label class='form-label'>Dominio</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🌐</span>
                                    <input type='text' name='${option}_domain' class='form-control domain-field' placeholder='Dominio' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Usuario BD</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>👤</span>
                                    <input type='text' name='${option}_db_user' class='form-control' placeholder='Usuario BD' required>
                                </div>
                            </div>
                            <div class='mb-3'>
                                <label class='form-label'>Contraseña BD</label>
                                <div class='input-group'>
                                    <span class='input-group-text'>🔑</span>
                                    <input type='password' name='${option}_db_pass' class='form-control' placeholder='Contraseña BD' required>
                                </div>
                            </div>
                        `;
                    }
                    html += `</div>`;
                    $('#dynamic-fields').append(html);
                });

                $('.domain-field').on('input', function() {
                    let domain = $(this).val().trim();
                    let domains = [];
                    $('.domain-field').each(function() {
                        let d = $(this).val().trim();
                        if(d) {
                            domains.push(d);
                        }
                    });
                    if (domain && domains.filter(d => d === domain).length > 1) {
                        alert('⚠ El dominio ' + domain + ' ya está en uso. Por favor, elige otro.');
                        $(this).val('');
                    }
                });
            }

            $('#installForm').submit(function(event) {
                event.preventDefault();

                let domains = [];
                let valid = true;
                $('.domain-field').each(function() {
                    let domain = $(this).val().trim();
                    if (!/^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(domain) || domains.includes(domain)) {
                        valid = false;
                        alert('Dominios inválidos o repetidos.');
                        return false;
                    }
                    domains.push(domain);
                });

                if (valid && this.checkValidity()) {
                    let confirmationList = $("#confirmationList").empty();
                    $(this).serializeArray().forEach(item => {
                        confirmationList.append(`<li><strong>${item.name}:</strong> ${item.value}</li>`);
                    });

                    $('#confirmationModal').modal('show');
                }
            });

            $('#confirmInstall').click(() => $('#installForm').off('submit').submit());
        });
    </script>
</body>
</html>
