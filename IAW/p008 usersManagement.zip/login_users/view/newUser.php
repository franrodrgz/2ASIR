<form action="managers/userManager.php" method="post">
	<input type="hidden" name="op" value="new">
	<input type="email" name="mail" placeholder="Correo electrónico" required>
	<input type="password" name="pass"  placeholder="Contraseña" required>
	<input type="text" name="name"  placeholder="Nombre" required>
	<input type="submit" value="Crear">
</form>
