<form action="admin.php" method="post">
	<input type="hidden" name="op" value="sch">
	<input type="text" name="textToSearch" size="50" required>
	<input type="submit" value="Buscar">
</form>