<?php
require_once('secureView.php');
require_once('secureAdm.php');
?>