<?php
require_once('secure.php');
sessionCheck();
?>